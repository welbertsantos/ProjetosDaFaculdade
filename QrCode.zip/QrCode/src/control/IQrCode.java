package control;
        
import modelBean.QrCode;
import java.util.List;

public interface IQrCode {
    
    boolean adicionar(QrCode qrcode);
    boolean alterar(QrCode qrcode);
    boolean excluir(QrCode qrcode);
    QrCode pesquisarPorId(int id);
    List<QrCode> pesquisaTodos();
    
}

    

