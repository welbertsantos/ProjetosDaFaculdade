/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.sound.sampled.AudioFormat.Encoding;

/**
 *
 * @author Note
 */
public class Criptografar {/*
     private Cipher cifraDES;
      KeyGenerator keygenerator = KeyGenerator.getInstance("DES");
     SecretKey chaveDES = keygenerator.generateKey();
    public Criptografar() throws NoSuchAlgorithmException, NoSuchPaddingException{
      // Cria a cifra
      cifraDES = Cipher.getInstance("DES/ECB/PKCS5Padding");
    }
    
    public String Criptografar () throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
        // Texto puro
        byte[] textoPuro = "Exemplo de texto puro".getBytes();
        
        // Inicializa a cifra para o processo de encriptação
        cifraDES.init(Cipher.ENCRYPT_MODE, (Key) chaveDES);
        
        
        // Texto encriptado
        byte[] textoEncriptado = cifraDES.doFinal(textoPuro);
        
        return String.valueOf(textoEncriptado);
    }
   
  
  

public String desencriptar(String texto) throws InvalidKeyException{
        // Inicializa a cifra para o processo de encriptação
    cifraDES.init(Cipher.ENCRYPT_MODE, chaveDES);
    // Texto encriptado
    
    

    byte[] textoEncriptado = cifraDES.doFinal(Encoding.ASCII.GetBytes(texto));
    return String.valueOf(textoEncriptado);
}
    */
}
