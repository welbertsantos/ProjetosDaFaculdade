package modelDao;

import java.sql.*;

public abstract class DaoUtil {
    private Connection cx = null;
    
    private Connection getConnection() throws ClassNotFoundException, SQLException{
        if(cx == null){
            String url = "jdbc:mysql://localhost:3306/qrcode";
            String psw = "";
            String usr = "root";
            Class.forName("com.mysql.cj.jdbc.Driver");
            cx = DriverManager.getConnection(url, usr, psw);
        }        
        return cx;
    }
    
    public void getFechaTudo() throws SQLException{
        if(cx != null){
            cx.close();
            cx=null;
        }
    }
    
    public Statement getStatement() throws ClassNotFoundException, SQLException{
        return this.getConnection().createStatement();
    }
    
    public PreparedStatement getPreparedStatement(String sql) throws ClassNotFoundException, SQLException{
        return this.getConnection().prepareStatement(sql);
    }
    
}
