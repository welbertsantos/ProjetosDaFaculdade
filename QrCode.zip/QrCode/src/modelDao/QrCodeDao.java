package modelDao;

import control.IQrCode;
import java.util.List;
import java.sql.*;
import java.util.LinkedList;
import java.util.logging.Level;
//import java.util.Date;
import java.sql.Date;
import java.util.logging.Logger;
import modelBean.QrCode;
import view.AdicionarView;

public class QrCodeDao extends DaoUtil implements IQrCode {

    public QrCodeDao() {
        super();
    }

    public boolean adicionar(QrCode qrcode) {
        String sql = "INSERT INTO qrcode (REMETENTE, DESCRICAO, DESCRICAOBREVE, QUANTIDADEDECAIXAS, QUANTIDADEPORCAIXA, DESTINO, DTENVIO, CODIGO) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        int ret=0;
        PreparedStatement ps;
        try {
            ps = super.getPreparedStatement(sql);
            ps.setString(1, qrcode.getRemetente());
            ps.setString(2, qrcode.getDescricao());
            ps.setString(3, qrcode.getDescricaobreve());
            ps.setInt(4, qrcode.getQuantidadedecaixas());
            ps.setInt(5, qrcode.getQuantidadeporcaixa());
            ps.setString(6, qrcode.getDestino());
            ps.setDate(7, qrcode.getDtenvio());
            ps.setInt(8, qrcode.getCodigo());
            ret = ps.executeUpdate();
            ps.close();            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(QrCodeDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(QrCodeDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return ret > 0;
    }
    
    public boolean alterar(QrCode qrcode) {
        String sql = "UPDATE qrcode SET DESCRICAO=?, DESCRICAOBREVE=?, QUANTIDADEDECAIXAS=?, QUANTIDADEPORCAIXA=?, DTVALIDADE=?, DESTINO=?, REMETENTE=? WHERE idqrcode=?";
        int ret=0;
        PreparedStatement ps;
        try {
           ps = super.getPreparedStatement(sql);
            ps.setString(1, qrcode.getDescricao());
            ps.setString(2, qrcode.getDescricaobreve());
            ps.setInt(3, qrcode.getQuantidadedecaixas());
            ps.setInt(4, qrcode.getQuantidadeporcaixa());
            ps.setDate(5, qrcode.getDtenvio());
            ps.setString(6, qrcode.getDestino());
             ps.setString(7, qrcode.getRemetente());
            ret = ps.executeUpdate();
            ps.close();            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(QrCodeDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(QrCodeDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return ret > 0;  
    }
    public boolean excluir(QrCode qrcode) {
        String sql = "DELETE FROM qrcode WHERE idqrcode=?";
        int ret=0;
        PreparedStatement ps;
        try {
            ps = super.getPreparedStatement(sql);
            ps.setInt(1, qrcode.getIdqrcode());
            ret = ps.executeUpdate();
            ps.close();            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(QrCodeDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(QrCodeDao.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
        return ret > 0;
    }
    
 public QrCode pesquisarPorId(int id) {
        QrCode qrcode = new QrCode();
        String sql = "SELECT idqrcode, Descricao, DescricaoBreve, QuantidadeDeCaixas, QuantidadePorCaixa , Dtenvio, Destino, Remetente FROM QrCode WHERE idqrcode";
        
        try {
            PreparedStatement ps = super.getPreparedStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                       
                qrcode.setIdqrcode(rs.getInt("idQrCode"));
                qrcode.setDescricao(rs.getString("Descricao"));
                qrcode.setDescricaobreve(rs.getString("DescricaoBreve"));
                qrcode.setDestino(rs.getString("Destino"));
                qrcode.setQuantidadedecaixas(rs.getInt("QuantidadeDeCaixas"));
                qrcode.setQuantidadeporcaixa(rs.getInt("QuantidadePorCaixa"));
                qrcode.setRemetente(rs.getString("Remetente"));
                qrcode.setDtenvio(rs.getDate("Dtenvio"));
            }
            rs.close();
            ps.close();
            super.getFechaTudo();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(QrCodeDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(QrCodeDao.class.getName()).log(Level.SEVERE, null, ex);
        }        
        
        
        return qrcode;    
    }
    
  public List<QrCode> pesquisaTodos() {
        List<QrCode> qrcode = new LinkedList<QrCode>();
        
        String sql = "SELECT idqrcode, Descricao, DescricaoBreve, QuantidadeDeCaixas, QuantidadePorCaixa , Dtenvio, Destino FROM QrCode";

        try {
            PreparedStatement ps = super.getPreparedStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                QrCode qrcodeclass = new QrCode();
                /*qrcode.add(new QrCode(rs.getInt("idQrCode"), 
                                    rs.getString("Descricao"),
                                    rs.getString("DescricaoBreve"),
                                    rs.getInt("QuantidadeDeCaixas"),
                                    rs.getInt("QuantidadeDeCaixas"),
                                    rs.getDate("Dtenvio"),
                                    rs.getString("Destino"))
                );*/
                qrcodeclass.setIdqrcode(rs.getInt("idQrCode"));
                qrcodeclass.setDescricao(rs.getString("Descricao"));
                qrcodeclass.setDescricaobreve(rs.getString("DescricaoBreve"));
                qrcodeclass.setDestino(rs.getString("Destino"));
                qrcodeclass.setQuantidadedecaixas(rs.getInt("QuantidadeDeCaixas"));
                qrcodeclass.setQuantidadeporcaixa(rs.getInt("QuantidadePorCaixa"));
                qrcodeclass.setRemetente(rs.getString("Remetente"));
                qrcodeclass.setDtenvio(rs.getDate("Dtenvio"));
                qrcode.add(qrcodeclass);
            }
            rs.close();
            ps.close();
            super.getFechaTudo();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(QrCodeDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(QrCodeDao.class.getName()).log(Level.SEVERE, null, ex);
        }        
        
        
        return qrcode;
    }
    
    
}
    
        
/* private int idqrcode;
    private String descricao;
    private String descricaobreve;
    private int quantidadedecaixas;
    private int quantidadeporcaixa;
    private Date dtenvio;
    private String destino;*/