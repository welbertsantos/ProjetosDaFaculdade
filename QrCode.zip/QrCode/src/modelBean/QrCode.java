package modelBean;

import java.sql.Date;

public class QrCode {

    private Integer idqrcode;
    private String descricao;
    private String descricaobreve;
    private Integer quantidadedecaixas;
    private Integer quantidadeporcaixa;
    private Date dtenvio;
    private String remetente;
    private Integer codigo;

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getRemetente() {
        return remetente;
    }

    public void setRemetente(String remetente) {
        this.remetente = remetente;
    }
    private String destino;

    public QrCode() {
    }

    public QrCode(Integer idqrcode, String descricao, String descricaobreve, Integer quantidadesdecaixas, Integer quantidadeporcaixa, String destino, Date dtenvio, String remetente) {
        this.idqrcode = idqrcode;
        this.descricao = descricao;
        this.descricaobreve = descricaobreve;
        this.quantidadedecaixas = quantidadedecaixas;
        this.quantidadeporcaixa = quantidadeporcaixa;
        this.dtenvio = dtenvio;
        this.destino = destino;
        this.remetente = remetente;
    }

    public Integer getIdqrcode() {
        return idqrcode;
    }

    public void setIdqrcode(Integer idqrcode) {
        this.idqrcode = idqrcode;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricaobreve() {
        return descricaobreve;
    }

    public void setDescricaobreve(String descricaobreve) {
        this.descricaobreve = descricaobreve;
    }

    public Integer getQuantidadedecaixas() {
        return quantidadedecaixas;
    }

    public void setQuantidadedecaixas(Integer quantidadedecaixas) {
        this.quantidadedecaixas = quantidadedecaixas;
    }

    public Integer getQuantidadeporcaixa() {
        return quantidadeporcaixa;
    }

    public void setQuantidadeporcaixa(Integer quantidadeporcaixa) {
        this.quantidadeporcaixa = quantidadeporcaixa;
    }

    public Date getDtenvio() {
        return dtenvio;
    }

    public void setDtenvio(Date dtenvio) {
        this.dtenvio = dtenvio;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

}